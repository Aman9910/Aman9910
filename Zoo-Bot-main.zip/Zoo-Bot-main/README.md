## ZOO BOT

## BOT FEATURE

- Auto Buy Animal
- Auto Feed Animal
- Auto task
- Auto upgrade
- Auto Join Alliance
- Auto Complete Quest/Quiz

## COOMANDS
```
pkg install nodejs-lts
```
```
pkg install git
```
   ```bash
   git clone https://github.com/Not-D4rkCipherX/Zoo-Bot.git
   ```
   ```bash
   cd Zoo-Bot
   ```

2. **Instal Requirements:**
   ```bash
   npm i
   ```
3. **ADD ACCOUNTS**
   ```
   nano data.txt
   ```
4.**START THE BOT**
```bash
node zoo.js
```
For Proxy :
```
node zoo-proxy.js
```
For those using multiple accounts, it's recommended to use a proxy (if using only one account, there's no need to create the proxy.txt file).

---

## PROXY FORMAT

```bash
http://username:passwoord@hostname:port
socks5://username:password@hostname:port
```
**TUTORIAL AVAILABLE ON MY YT**
